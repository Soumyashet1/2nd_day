-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 23, 2017 at 06:57 PM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel_expense`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_employee` ()  BEGIN
SELECT t.travel_id,t.travel_name,GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price
FROM travels t,travels_assigned ta,expenses e,employees emp
WHERE t.travel_id=ta.travel_id
AND ta.travel_assigned_id=e.expense_travel_assigned_id
AND ta.employee_id=emp.employee_id
GROUP BY t.travel_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `new_procedure` ()  BEGIN
SELECT t.travel_id,t.travel_name,GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price
FROM travels t,travels_assigned ta,expenses e,employees emp
WHERE t.travel_id=ta.travel_id
AND ta.travel_assigned_id=e.expense_travel_assigned_id
AND ta.employee_id=emp.employee_id
GROUP BY t.travel_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`) VALUES
(1, 'Operations'),
(2, 'Engineering'),
(3, 'Sales'),
(4, 'Marketing'),
(5, 'HR'),
(6, 'Finance');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `employee_role_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `employee_created_by_id` int(11) NOT NULL,
  `employee_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employee_id`, `first_name`, `last_name`, `email_id`, `password`, `employee_role_id`, `department_id`, `employee_created_by_id`, `employee_created_on`) VALUES
(1, 1100, 'Ramesh', 'B', 'r@aissel.com', '25d55ad283aa400af464c76d713c07ad', 2, 2, 1100, '2017-06-22 08:29:57'),
(2, 1118, 'Soumya', 'Shet', 's@aissel.com', 'd7812b94b1962436cd28c7b5004e059e', 1, 2, 1100, '2017-06-22 08:31:20'),
(3, 1120, 'Deepa', 'G', 'd@aissel.com', '29987ce14a9c7b9137f616843eca049b', 1, 1, 1100, '2017-06-22 08:36:40'),
(4, 1119, 'Vinuta', 'K', 'v@gmail.com', '1430913c41a2394d7222d45ff62019a6', 1, 3, 1100, '2017-06-22 08:32:37'),
(5, 1121, 'Uday', 'Haliyal', 'u@aissel.com', '64cdce3a9cbb8e3a4209bd3b6c1add09', 1, 4, 1100, '2017-06-22 08:37:26'),
(6, 1122, 'Kumaresh', 'B', 'k@aissel.com', '36287f66ce7742829d47501a153e1b57', 1, 6, 1100, '2017-06-22 08:38:01'),
(7, 2323, 'dfdf', 'dfdf', 'dfdf', '232323', 1, 1, 1100, '2017-06-12 12:18:29'),
(8, 5555, 'Johny', 'Smith', 'john@abc.com', '123123', 2, 4, 1100, '2017-06-20 08:40:49'),
(11, 999, 'sddd', 'sdd', 'sss', 'ssd', 1, 1, 1100, '2017-06-12 12:25:06'),
(23, 90, 'gjk', 'fkjh', 'e@gmail.com', '8613985ec49eb8f757ae6439e879bb2a', 1, 3, 1100, '2017-06-23 12:36:53'),
(24, 66, 'hh', 'hh', 'hh', '5e36941b3d856737e81516acd45edc50', 1, 2, 1100, '2017-06-23 13:26:25');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL,
  `expense_travel_assigned_id` int(11) NOT NULL,
  `expense_date` date DEFAULT NULL,
  `expense_time` time DEFAULT NULL,
  `expense_category_id` int(11) DEFAULT NULL,
  `expense_desc` varchar(200) DEFAULT NULL,
  `expense_price` float NOT NULL,
  `expense_attach` varchar(255) DEFAULT NULL,
  `expense_status_id` int(11) NOT NULL DEFAULT '1',
  `expense_created_by_id` int(11) DEFAULT NULL,
  `expense_created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expense_id`, `expense_travel_assigned_id`, `expense_date`, `expense_time`, `expense_category_id`, `expense_desc`, `expense_price`, `expense_attach`, `expense_status_id`, `expense_created_by_id`, `expense_created_on`) VALUES
(1, 1, '2017-06-09', '10:00:00', 2, 'lunch', 130, 'noimage.jpg', 3, 1118, '2017-06-23 09:06:46'),
(2, 1, '2017-06-10', '14:00:00', 2, 'auto', 30, 'noimage.jpg', 3, 1118, '2017-06-22 06:17:03'),
(3, 1, '2017-06-11', '05:00:00', 3, 'xeroxhhh', 50, 'noimage.jpg', 3, 1118, '2017-06-23 08:52:07'),
(4, 2, '2017-06-09', '21:11:00', 1, 'dinner', 180, 'noimage.jpg', 3, 1122, '2017-06-22 12:23:35'),
(5, 2, '2017-06-12', '07:00:00', 1, 'tiffin', 30, 'noimage.jpg', 3, 1122, '2017-06-22 06:17:03'),
(6, 3, '2017-06-09', '08:00:00', 1, 'tiffin', 30, 'noimage.jpg', 1, 1119, '2017-06-22 06:17:03'),
(7, 3, '2017-06-09', '15:00:00', 1, 'lunch', 100, 'noimage.jpg', 3, 1119, '2017-06-22 06:17:03'),
(8, 4, '2017-06-22', '23:00:00', 2, 'ticket price', 800, 'noimage.jpg', 1, 1121, '2017-06-22 06:17:03'),
(9, 4, '2017-06-23', '10:00:00', 4, 'room rent', 450.5, 'noimage.jpg', 2, 1121, '2017-06-22 06:17:03'),
(10, 4, '2017-06-27', '16:00:00', 2, 'ticket price', 900, 'noimage.jpg', 3, 1121, '2017-06-22 06:17:03'),
(11, 4, '2017-06-27', '14:00:00', 1, 'lunch', 80, 'noimage.jpg', 3, 1121, '2017-06-22 06:17:03'),
(12, 5, '2017-06-22', '10:00:00', 2, 'city bus ticket price', 20, 'noimage.jpg', 1, 1120, '2017-06-22 06:17:03'),
(13, 7, '2017-06-28', '22:00:00', 1, 'dinner', 140, 'noimage.jpg', 1, 1119, '2017-06-22 06:17:03'),
(14, 7, '2017-06-29', '10:00:00', 2, 'auto', 80, 'noimage.jpg', 2, 1119, '2017-06-22 06:17:03'),
(15, 8, '2017-06-28', '12:00:00', 3, 'stationery', 40, 'noimage.jpg', 1, 1121, '2017-06-22 06:17:03'),
(16, 8, '2017-06-29', '19:00:00', 4, 'room rent', 600, 'noimage.jpg', 3, 1121, '2017-06-22 06:17:03'),
(17, 9, '2017-06-28', '16:00:00', 1, 'evening snacks', 30, 'noimage.jpg', 1, 1122, '2017-06-22 06:17:03'),
(18, 9, '2017-06-29', '08:00:00', 2, 'bus ticket', 20, 'noimage.jpg', 1, 1122, '2017-06-22 06:17:03'),
(19, 10, '2017-06-28', '13:00:00', 3, 'stationery', 80, 'noimage.jpg', 3, 1119, '2017-06-23 07:09:05'),
(20, 10, '2017-06-29', '15:00:00', 4, 'room rent', 1100, 'noimage.jpg', 3, 1119, '2017-06-22 06:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `expense_category_id` int(11) NOT NULL,
  `expense_category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`expense_category_id`, `expense_category_name`) VALUES
(1, 'Food'),
(2, 'Transportation'),
(3, 'Accomodation'),
(4, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `expense_statuses`
--

CREATE TABLE `expense_statuses` (
  `expense_status_id` int(11) NOT NULL,
  `expense_status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense_statuses`
--

INSERT INTO `expense_statuses` (`expense_status_id`, `expense_status_name`) VALUES
(1, 'Pending'),
(2, 'Accepted'),
(3, 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1, 'Employee'),
(2, 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `travels`
--

CREATE TABLE `travels` (
  `travel_id` int(11) NOT NULL,
  `travel_name` varchar(255) NOT NULL,
  `travel_desc` text NOT NULL,
  `travel_start_date` date NOT NULL,
  `travel_end_date` date NOT NULL,
  `travel_status_id` int(11) NOT NULL DEFAULT '1',
  `travel_created_by_id` int(11) NOT NULL,
  `travel_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travels`
--

INSERT INTO `travels` (`travel_id`, `travel_name`, `travel_desc`, `travel_start_date`, `travel_end_date`, `travel_status_id`, `travel_created_by_id`, `travel_created_on`) VALUES
(1, 'Recruitment Drive in bengaluru', 'Recruitment Drive in bengaluru for MBA graduates in ramaiyya collage....', '2017-06-09', '2017-06-13', 1, 1100, '2017-06-07 09:38:54'),
(2, 'AWS Training', 'AWS Training in Mumbai', '2017-06-22', '2017-06-27', 1, 1100, '2017-06-07 09:41:32'),
(3, 'Marketing team KT', 'Marketing team KT in Goa', '2017-06-28', '2017-06-29', 1, 1100, '2017-06-07 09:42:15'),
(4, 'Recruitment Drive in Goa', 'Recruitment Drive in Goa for B.E graduates', '2017-06-09', '2017-06-18', 1, 1100, '2017-06-07 09:46:03'),
(40, 'hh', 'travel description', '2017-06-16', '2017-06-24', 0, 1100, '2017-06-22 12:44:02'),
(41, 'gte', 'gdfgd', '2017-06-07', '2017-06-09', 0, 1100, '2017-06-22 12:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `travels_assigned`
--

CREATE TABLE `travels_assigned` (
  `travel_assigned_id` int(11) NOT NULL,
  `travel_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travels_assigned`
--

INSERT INTO `travels_assigned` (`travel_assigned_id`, `travel_id`, `employee_id`) VALUES
(1, 1, 1118),
(2, 1, 1122),
(3, 1, 1119),
(4, 2, 1121),
(5, 2, 1120),
(6, 3, 1119),
(7, 3, 1120),
(8, 3, 1121),
(9, 3, 1122),
(10, 4, 1119),
(11, 39, 1118),
(12, 39, 1121),
(13, 39, 1122),
(14, 40, 1121),
(15, 40, 1122),
(16, 41, 1118),
(17, 41, 1119);

-- --------------------------------------------------------

--
-- Table structure for table `travel_statuses`
--

CREATE TABLE `travel_statuses` (
  `travel_status_id` int(11) NOT NULL,
  `travel_status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travel_statuses`
--

INSERT INTO `travel_statuses` (`travel_status_id`, `travel_status_name`) VALUES
(1, 'Ongoing'),
(2, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `try`
--

CREATE TABLE `try` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `try`
--

INSERT INTO `try` (`id`, `tid`, `eid`) VALUES
(1, 99, 1),
(2, 99, 2),
(5, 200, 100),
(6, 200, 101);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`,`employee_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`expense_category_id`);

--
-- Indexes for table `expense_statuses`
--
ALTER TABLE `expense_statuses`
  ADD PRIMARY KEY (`expense_status_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `travels`
--
ALTER TABLE `travels`
  ADD PRIMARY KEY (`travel_id`);

--
-- Indexes for table `travels_assigned`
--
ALTER TABLE `travels_assigned`
  ADD PRIMARY KEY (`travel_assigned_id`);

--
-- Indexes for table `travel_statuses`
--
ALTER TABLE `travel_statuses`
  ADD PRIMARY KEY (`travel_status_id`);

--
-- Indexes for table `try`
--
ALTER TABLE `try`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expense_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `expense_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `expense_statuses`
--
ALTER TABLE `expense_statuses`
  MODIFY `expense_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `travels`
--
ALTER TABLE `travels`
  MODIFY `travel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `travels_assigned`
--
ALTER TABLE `travels_assigned`
  MODIFY `travel_assigned_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `travel_statuses`
--
ALTER TABLE `travel_statuses`
  MODIFY `travel_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `try`
--
ALTER TABLE `try`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
