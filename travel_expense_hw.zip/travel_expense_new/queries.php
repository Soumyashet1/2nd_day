SELECT e.expense_id,t.travel_name,ep.first_name,e.expense_date,e.expense_time,
ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name
FROM expenses e,expense_statuses es,travels t, travels_assigned ta,employees ep,expense_categories ec
WHERE e.expense_status_id=es.expense_status_id
AND e.expense_travel_assigned_id=ta.travel_assigned_id
AND ta.travel_id=t.travel_id
AND ta.employee_id=ep.employee_id
AND e.expense_category_id=ec.expense_category_id
ORDER BY e.expense_id


----------------admin overall view----------------
SELECT t.travel_id,t.travel_name,GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price
FROM travels t,travels_assigned ta,expenses e,employees emp
WHERE t.travel_id=ta.travel_id
AND ta.travel_assigned_id=e.expense_travel_assigned_id
AND ta.employee_id=emp.employee_id
GROUP BY t.travel_id

---------------wen admin selects a particular travel-----------
SELECT e.expense_id,ep.first_name,e.expense_date,e.expense_time,
ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name
FROM expenses e,expense_statuses es,travels t, travels_assigned ta,employees ep,expense_categories ec
WHERE e.expense_status_id=es.expense_status_id
AND e.expense_travel_assigned_id=ta.travel_assigned_id
AND ta.travel_id=t.travel_id
AND ta.employee_id=ep.employee_id
AND e.expense_category_id=ec.expense_category_id
AND t.travel_id=1
ORDER BY e.expense_id


----------------wen an employee(1118) clicks travel(1)-----
SELECT e.expense_id,e.expense_date,e.expense_time,
ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name
FROM expenses e
LEFT JOIN expense_statuses es ON e.expense_status_id=es.expense_status_id
LEFT JOIN expense_categories ec ON e.expense_category_id=ec.expense_category_id
LEFT JOIN travels_assigned ta ON e.expense_travel_assigned_id=ta.travel_assigned_id
WHERE  ta.travel_id=4
AND ta.employee_id=1119
ORDER BY e.expense_id


-----------------employee view (1119)-----------------------
SELECT t.travel_id,t.travel_name,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price FROM travels t,travels_assigned ta,expenses e,employees emp WHERE t.travel_id=ta.travel_id AND ta.travel_assigned_id=e.expense_travel_assigned_id AND ta.employee_id=emp.employee_id AND emp.employee_id=1119 GROUP BY t.travel_id

SELECT t.travel_id,t.travel_name,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price FROM travels t
LEFT JOIN travels_assigned ta ON  t.travel_id=ta.travel_id
LEFT JOIN expenses e ON ta.travel_assigned_id=e.expense_travel_assigned_id
LEFT JOIN employees emp ON ta.employee_id=emp.employee_id
WHERE emp.employee_id=1121
GROUP BY t.travel_id


SELECT e.employee_id,e.first_name,e.last_name,e.email_id,r.role_name,d.department_name
FROM employees e
LEFT JOIN roles r ON e.employee_role_id=r.role_id
LEFT JOIN departments d ON d.department_id=e.department_id



type: "POST",
enctype: 'multipart/form-data',
processData: false,  // Important!
contentType: false,
cache: false,




enctype: 'multipart/form-data',
processData: false,  // Important!
contentType: false,
cache: false





       timeout: 600000,
       success: function (




            enctype: 'multipart/form-data',


            processData: false,

            cache: false,
            timeout: 600000,
            success: function (data) {

                $("#result").text(data);
                console.log("SUCCESS : ", data);
                $("#btnSubmit").prop("disabled", false);

            },




            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>CodeIgniter Modal Contact Form Example</title>
                <!--load bootstrap css-->
                <link href="<?php echo base_url("assets/bootstrap/css/bootstrap.css"); ?>" rel="stylesheet" type="text/css" />
            </head>
            <body>
            <!-- Navigation Menu -->
            <nav class="navbar navbar-inverse" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#">ShopMania</a>
                    </div>
                    <div class="collapse navbar-collapse" id="navbar1">
                        <ul class="nav navbar-nav">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Deals & Offers</a></li>
                            <li><a href="#">Blog</a></li>
                            <li class="active"><a href="#" data-toggle="modal" data-target="#myModal">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <!-- modal form -->
          <div id="myModal" class="modal fade" aria-labelledby="myModalLabel" aria-hidden="true" tabindex="-1" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <?php $attributes = array("name" => "contact_form", "id" => "contact_form");
                        echo form_open("modal_contact/submit", $attributes);?>

                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Contact Form</h4>
                        </div>
                        <div class="modal-body" id="myModalBody">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input class="form-control" id="name" name="name" placeholder="Your Full Name" type="text" value="<?php echo set_value('name'); ?>" />
                            </div>

                            <div class="form-group">
                                <label for="email">Email ID</label>
                                <input class="form-control" id="email" name="email" placeholder="Email-ID" type="text" value="<?php echo set_value('email'); ?>" />
                            </div>

                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input class="form-control" id="subject" name="subject" placeholder="Subject" type="text" value="<?php echo set_value('subject'); ?>" />
                            </div>

                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea class="form-control" id="message" name="message" rows="4" placeholder="Message"><?php echo set_value('message'); ?></textarea>
                            </div>

                            <div id="alert-msg"></div>
                        </div>
                        <div class="modal-footer">
                            <input class="btn btn-default" id="submit" name="submit" type="button" value="Send Mail" />
                            <input class="btn btn-default" type="button" data-dismiss="modal" value="Close" />
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
            <!--load jquery & bootstrap js files-->
            <script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
            <script src="<?php echo base_url("assets/bootstrap/js/bootstrap.min.js"); ?>"></script>
            <script type="text/javascript">
            $('#submit').click(function() {
                var form_data = {
                    name: $('#name').val(),
                    email: $('#email').val(),
                    subject: $('#subject').val(),
                    message: $('#message').val()
                };
                $.ajax({
                    url: "<?php echo site_url('modal_contact/submit'); ?>",
                    type: 'POST',
                    data: form_data,
                    success: function(msg) {
                        if (msg == 'YES')
                            $('#alert-msg').html('<div class="alert alert-success text-center">Your mail has been sent successfully!</div>');
                        else if (msg == 'NO')
                            $('#alert-msg').html('<div class="alert alert-danger text-center">Error in sending your message! Please try again later.</div>');
                        else
                            $('#alert-msg').html('<div class="alert alert-danger">' + msg + '</div>');
                    }
                });
                return false;
            });
            </script>
            </body>
            </html>

































<script type="text/javascript">
    $("#btnSave").click(function (event) {
    event.preventDefault();
    var form = $('#form')[0];
    var data = new FormData(form);
    console.log(data);
    alert("hi");
   // ajax adding data to database
      $.ajax({
        url : "<?php echo base_url(); ?>documents/do_upload/",
        type: "POST",
        enctype: 'multipart/form-data',
        data: data,
        processData: false,
        contentType: false,
        cache: false,
        success: function(data)
        {
             $("#modal_form").removeClass("in");
             $(".modal-backdrop").remove();
             $("#modal_form").hide();
        },
    });
});
