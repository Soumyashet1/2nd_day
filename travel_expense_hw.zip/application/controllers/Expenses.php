<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expenses extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('expense');
	}
	public function index() //admin view of all travels
	{
		$data['data']= $this->expense->getAllTravelsExpenses();
		$data['contents'] = "expense/admin_view_on_all_travels";
		$this->load->view('layouts/navbar',$data);
	}
	public function travel_specific($tid) ///(admin view)shows expenses of particular travel
	{
		$pending="pending";
		$accepted="accepted";
		$rejected="rejected";
		$all="all";
		$data['all']= $this->expense->getTravelSpecificExpenses($tid,$all);
		$data['pending']= $this->expense->getTravelSpecificExpenses($tid,$pending);
		$data['accepted']= $this->expense->getTravelSpecificExpenses($tid,$accepted);
		$data['rejected']= $this->expense->getTravelSpecificExpenses($tid,$rejected);
		$data['contents'] = "expense/admin_view_on_particular_travel";
		$this->load->view('layouts/navbar',$data);
	}
	public function user_travel_specific($tid) //shows expenses of particular   user and travel
	{
		$pending="pending";
		$accepted="accepted";
		$rejected="rejected";
		$all="all";
		$eid=$_SESSION['uid'];
		$data['tid']= $tid;
		$data['categories']= $this->expense->getExpenseCategories();
		$data['all']= $this->expense->getTravelSpecificExpensesOfUser($tid,$eid,$all);
		$data['pending']= $this->expense->getTravelSpecificExpensesOfUser($tid,$eid,$pending);
		$data['accepted']= $this->expense->getTravelSpecificExpensesOfUser($tid,$eid,$accepted);
		$data['rejected']= $this->expense->getTravelSpecificExpensesOfUser($tid,$eid,$rejected);
		$data['contents'] = "expense/user_view_on_particular_travel";
		$this->load->view('layouts/navbar',$data);
	}
	public function expense_add($tid)
	{
		$image_rename=time().$_FILES['userfile']['name'];
		$config['upload_path']= 'images';
		$config['allowed_types']= 'gif|jpg|png';
		$config['max_size']= '2048';
		$config['max_width']= '2000';
		$config['max_height']= '2000';
		$config['file_name'] = $image_rename;
		$this->load->library('upload',$config);
    $zdata = array('upload_data' => $this->upload->data()); // get data
    $zfile = $zdata['upload_data']['full_path']; // get file path
    chmod($zfile,0777);
		if(!$this->upload->do_upload('userfile'))
		{
			$errors=array('error',$this->upload->display_errors());
			$post_image='noimage.jpg';
		}
		else {
		 $data=array('upload_data',$this->upload->data());
		 $post_image=$image_rename;
		}
		$employee_id=$_SESSION['uid'];
		$travel_id=$tid;
		$travel_assigned_id=$this->expense->getTravelAssignedId($employee_id,$travel_id);
		$data = array(
			'expense_id' => $this->input->post('expense_id'),
			'expense_date' => $this->input->post('expense_date'),
			'expense_time' => $this->input->post('expense_time'),
			'expense_category_id' => $this->input->post('expense_category_id'),
			'expense_desc' => $this->input->post('expense_description'),
			'expense_price' => $this->input->post('expense_price'),
			'expense_attach' => $post_image,
			'expense_created_by_id' => $_SESSION['uid'],
			'expense_travel_assigned_id' => $travel_assigned_id
		);
		$insert = $this->expense->addExpense($data);
		echo json_encode(array("status" => TRUE));
	}
	public function edit_exp_accepted($e)//edits status of a particular expense
	{
		$data = array(
				'expense_status_id' =>'2',
		);
		$this->expense->updateExpenseStatus(array('expense_id' =>$e ), $data);
		echo json_encode(array("status" => TRUE));
	}
	public function edit_exp_rejected($e)//edits status of a particular expense
	{
		$data = array(
				'expense_status_id' =>'3',
		);
		$this->expense->updateExpenseStatus(array('expense_id' =>$e ), $data);
		echo json_encode(array("status" => TRUE));
	}
	public function delete_expense($id) //delete expense row n expense attachment from folder
	{
		$get_pic_name=$this->expense->getImage($id);
		if($get_pic_name != 'noimage.jpg')
		{
		$filename=$_SERVER['DOCUMENT_ROOT'];
    $filename ="$filename/travel_expense/images/$get_pic_name";
  	unlink($filename);
		}
    $this->expense->deleteExpenseById($id);
		echo json_encode(array("status" => TRUE));
	}
	public function get_expense_details_by_id($id)// get details of oly selcted user to edit form
	{
		$data = $this->expense->getById($id);
		echo json_encode($data);
	}
	public function update_expense_details()//updating expense_details
	{
		$get_pic_name=$this->expense->getImage($this->input->post('expense_id'));
		if($get_pic_name != 'noimage.jpg')
		{
		$filename=$_SERVER['DOCUMENT_ROOT'];
		$filename ="$filename/travel_expense/images/$get_pic_name";
		unlink($filename);
		}
		$image_rename=time().$_FILES['userfile']['name'];
		$config['upload_path']= 'images';
		$config['allowed_types']= 'gif|jpg|png';
		$config['max_size']= '2048';
		$config['max_width']= '2000';
		$config['max_height']= '2000';
		$config['file_name'] = $image_rename;
		$this->load->library('upload',$config);
    $zdata = array('upload_data' => $this->upload->data()); // get data
    $zfile = $zdata['upload_data']['full_path']; // get file path
    chmod($zfile,0777);
		if(!$this->upload->do_upload('userfile'))
		{
			$errors=array('error',$this->upload->display_errors());
			$post_image='noimage.jpg';
		}
		else {
		 $data=array('upload_data',$this->upload->data());
		 $post_image=$image_rename;
		}
		$data = array(
			'expense_id' => $this->input->post('expense_id'),
			'expense_date' => $this->input->post('expense_date'),
			'expense_time' => $this->input->post('expense_time'),
			'expense_category_id' => $this->input->post('expense_category_id'),
			'expense_desc' => $this->input->post('expense_description'),
			'expense_price' => $this->input->post('expense_price'),
			'expense_attach' => $post_image,
			'expense_created_by_id' => $_SESSION['uid'],
		);
		$this->expense->updateExpense(array('expense_id' => $this->input->post('expense_id')),$data);
		echo json_encode(array("status" => TRUE));
	}
}
