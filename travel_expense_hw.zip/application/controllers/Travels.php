<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travels extends CI_Controller {
  public function __construct()
  {
    parent::__construct();
    $this->load->model('travel');
    $this->load->model('login');
  }
  public function index()//(admin_view)shows all travels list wit expenditure
  {
    $data['travel']=$this->travel->getAllTravels();
    $data['employees']=$this->login->getEmployees();
    $data['contents'] = "travels/travel_page";
    $this->load->view('layouts/navbar',$data);
  }
  public function add_travel()//adding new travel
  {
    $data = array(
        'travel_id' => $this->input->post('tid'),
        'travel_name' => $this->input->post('travel_name'),
        'travel_desc' => $this->input->post('travel_description'),
        'travel_start_date' => $this->input->post('travel_start_date'),
        'travel_end_date' => $this->input->post('travel_end_date'),
        'travel_status_id' => $this->input->post('travel_status_id'),
        'travel_created_by_id'=> $_SESSION['uid']
        );
    $data['inserted_travel_id'] =$this->travel->addTravel($data);
    $data['employee_ids']=$this->input->post('employee_ids');
    $this->travel->assignEmployeesForTravel($data);
    echo json_encode(array("status" => TRUE));
  }
  public function delete_travel($id)//delete travel
  {
    $this->travel->deleteById($id);
    echo json_encode(array("status" => TRUE));
  }
  public function get_travel_details_by_id($id)// get details of oly selcted travel to edit form
  {
    $data = $this->travel->getById($id);
    echo json_encode($data);
  }
  public function update_travel_details()//updating travel_details
  {
    $data = array(
        'travel_id' => $this->input->post('tid'),
        'travel_name' => $this->input->post('travel_name'),
        'travel_desc' => $this->input->post('travel_description'),
        'travel_start_date' => $this->input->post('travel_start_date'),
        'travel_end_date' => $this->input->post('travel_end_date'),
        'travel_status_id' => $this->input->post('travel_status_id'),
        'travel_created_by_id'=> $_SESSION['uid']
        );
    $this->travel->updateTravelDetails(array('travel_id' => $this->input->post('tid')),$data);
    echo json_encode(array("status" => TRUE));
  }
}
