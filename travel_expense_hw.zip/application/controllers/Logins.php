<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logins extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login');
		$this->load->model('expense');
	}
	public function index()// views login page
	{
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('password','Password','required');
		if($this->form_validation->run() != FALSE)
		{
			$email = $this->input->post('email');
			$password = md5($this->input->post('password')); //encrypted password
			$uresult = $this->Login->getUser($email, $password);
			if (count($uresult) > 0) //if user exists
			{
				$sess_data = array('login' => TRUE, //intialise session variables
					'uname' => $uresult[0]->first_name,
					'uid' => $uresult[0]->employee_id,
					'logged_in' =>'TRUE',
					'urole' => $uresult[0]->employee_role_id
					);
				$this->session->set_userdata($sess_data);
				if ( $uresult[0]->employee_role_id == 2) //if user is manager
				{
					redirect("expenses");
				}
				else    //user is employee
				{
					redirect("/logins/employee");
				}
			}
			else
			{
				$data['contents'] = "login/login_page";
				$this->load->view('layouts/navbar',$data);
				}
		}
		else
		{
			$data['contents'] = "login/login_page";
			$this->load->view('layouts/navbar',$data);//load the  same page if credentials r wrong
		}
	}
	public function users() //admin vview on users (crud on users model)
	{
		$data['roles']=$this->Login->getRoles();
		$data['departments']=$this->Login->getDepartments();
		$data['user']=$this->Login->getAllUsers();
		$data['contents'] = "login/users";
		$this->load->view('layouts/navbar',$data);
	}
	public function employee()//employee view of his travels
	{
		$eid=$_SESSION['uid'];
		$data['expense']=$this->expense->getAllTravelsExpensesOfUser($eid);
		$data['contents'] = "expense/user_view_on_all_travels";
		$this->load->view('layouts/navbar',$data);
	}
	public function add_user() //adding new user
	{
			$data = array(
				'id' => $this->input->post('id'),
				'employee_id' => $this->input->post('employee_id'),
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'email_id' => $this->input->post('email_id'),
				'password' => md5($this->input->post('password')),
				'employee_role_id'=> $this->input->post('employee_role_id'),
				'department_id'=> $this->input->post('dept_id'),
				'employee_created_by_id' => $_SESSION['uid']
				);
			$insert = $this->Login->addUser($data);
			echo json_encode(array("status" => TRUE));

  }
	public function delete_user($id) //delete user
	{
		$this->Login->deleteById($id);
		echo json_encode(array("status" => TRUE));
	}
	public function get_user_details_by_id($id)// get details of oly selcted user to edit form
	{
		$data = $this->Login->getById($id);
		echo json_encode($data);
	}
	public function update_user_details()//updating user_details
	{
		$data = array(
			'id' => $this->input->post('id'),
			'employee_id' => $this->input->post('employee_id'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'email_id' => $this->input->post('email_id'),
			'password' => $this->input->post('password'),
			'employee_role_id'=> $this->input->post('employee_role_id'),
			'department_id'=> $this->input->post('dept_id'),
			'employee_created_by_id' => $_SESSION['uid']
			);
		$this->Login->updateUser(array('id' => $this->input->post('id')),$data);
		echo json_encode(array("status" => TRUE));
	}
	public function logout()          //logout
	{
		$data = array('login' => '', 'uname' => '', 'uid' => '','logged_in' => '');
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		redirect('/Logins');
	}
}
