<?php
class Login extends CI_Model {
	var $table = 'employees';
	public function __construct()
	{
		parent::__construct();
	}
	public function getUser($email,$pwd)//get user details from email id n password entered in login page
	{
		$this->db->where('email_id', $email);
		$this->db->where('password',($pwd));
		$query = $this->db->get('employees');
		return $query->result();
	}
	public function getRoles() //get all roles ,reqd while entering new/updating user
	{
		$query = $this->db->get('roles');
		return $query->result();
	}
	public function getDepartments() //get all departments,reqd while entering new/updating user
	{
		$query = $this->db->get('departments');
		return $query->result();
	}
	public function getById($id)//fetch oly details of a particular user,for updating
	{
		$this->db->from($this->table);
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row();
	}
	public function deleteById($id)//delete user
	{
		$this->db->where('id', $id);
		$this->db->delete($this->table);
	}
	public function addUser($data)//adding new user
	{
		$this->db->insert($this->table,$data);
		return $this->db->insert_id();
	}
	public function updateUser($where,$data)//updating user
	{
		$this->db->update($this->table,$data,$where);
		return $this->db->affected_rows();
	}
	public function getAllUsers()//get all users wit role N dept names
	{
		$this->db->select('e.id,e.employee_id,e.first_name,e.last_name,e.email_id,r.role_name,d.department_name');
		$this->db->from('employees e');
		$this->db->join('roles r', 'e.employee_role_id=r.role_id');
		$this->db->join('departments d', 'd.department_id=e.department_id');
		$this->db->order_by('e.id');
		$query = $this->db->get();
		return $query->result();
	}
	public function getEmployees()//return employees table
	{
		$query = $this->db->get('employees');
		return $query->result();
	}
}
?>
