<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expense extends CI_Model
{
	var $table = 'expenses';
	public function getExpenseCategories()//shows all expenses catogories,reqd while filling expense form   //expense_categories
	{
		$query = $this->db->get('expense_categories');
		return $query->result();
	}
	public function addExpense($data)//adding new expense //expense_add
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}
	public function updateExpenseStatus($where,$data)//update status of expense ,accept/reject  //status_update
	{
		$this->db->update($this->table,$data,$where);
		return $this->db->affected_rows();
	}
	public function	getTravelAssignedId($employee_id,$travel_id)//update status of expense ,accept/reject //get_travel_assigned_id
	{
		$this->db->select('travel_assigned_id');
		$this->db->from('travels_assigned');
		$this->db->where('travel_id',$travel_id);
		$this->db->where('employee_id',$employee_id);
		$query = $this->db->get();
		return $query->row()->travel_assigned_id;
	}
	public function getAllTravelsExpenses()//admin view of all travels //get_all_expenses
	{
		$this->db->select('t.travel_id,t.travel_name,GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price');
		$this->db->from('travels t');
		$this->db->join('travels_assigned ta','t.travel_id=ta.travel_id');
		$this->db->join('expenses e','ta.travel_assigned_id=e.expense_travel_assigned_id');
		$this->db->join('employees emp','ta.employee_id=emp.employee_id');
		$this->db->group_by('t.travel_id');
		$query = $this->db->get();
		return $query->result();
	}
	public function getTravelSpecificExpenses($tid,$status)//(admin view)shows expenses of particular travel // get_travel_specific_expenses
	{
		$this->db->select('e.expense_id,ep.first_name,e.expense_date,e.expense_time,
		                         ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name');
		$this->db->from('expenses e');
		$this->db->join('expense_statuses es','e.expense_status_id=es.expense_status_id');
		$this->db->join('expense_categories ec','e.expense_category_id=ec.expense_category_id');
		$this->db->join('travels_assigned ta','e.expense_travel_assigned_id=ta.travel_assigned_id');
		$this->db->join('employees ep','ta.employee_id=ep.employee_id');
		$this->db->join('travels t','ta.travel_id=t.travel_id');
		$this->db->where('t.travel_id',$tid);
		if ($status != 'all')
		{
		$this->db->where('es.expense_status_name',$status);
		}
		$this->db->order_by('e.expense_id');
		$query = $this->db->get();
		return $query->result();
	}
	public function getAllTravelsExpensesOfUser($eid)///shows all travel of particular user with sum of price // get_user_specific_expenses
	{
		$this->db->select('t.travel_id,t.travel_name,t.travel_desc,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price');
		$this->db->from('travels t');
		$this->db->join('travels_assigned ta', 't.travel_id=ta.travel_id','left');
		$this->db->join('expenses e', 'ta.travel_assigned_id=e.expense_travel_assigned_id','left');
		$this->db->join('employees emp', 'ta.employee_id=emp.employee_id','left');
		$this->db->where('emp.employee_id',$eid);
		$this->db->group_by('t.travel_id');
		$query = $this->db->get();
		return $query->result();
	}
	public function getTravelSpecificExpensesOfUser($tid,$eid,$status)//(user view)shows expenses of particular travel //user_travel_specific_expenses
	{
		$this->db->select('e.expense_id,e.expense_date,e.expense_time,ec.expense_category_name,
		                       e.expense_desc,e.expense_price,e.expense_attach,es.expense_status_name');
		$this->db->from('expenses e');
		$this->db->join('expense_statuses es','e.expense_status_id=es.expense_status_id');
		$this->db->join('expense_categories ec','e.expense_category_id=ec.expense_category_id');
		$this->db->join('travels_assigned ta','e.expense_travel_assigned_id=ta.travel_assigned_id');
		$this->db->join('travels t','ta.travel_id=t.travel_id');
		$this->db->where('t.travel_id',$tid);
		$this->db->where('ta.employee_id',$eid);
		if ($status != 'all')
		{
			$this->db->where('es.expense_status_name',$status);
		}
		$this->db->order_by('e.expense_id');
		$query = $this->db->get();
		return $query->result();
	}

	public function deleteExpenseById($id)//delete user //delete_by_id
	{
		$this->db->where('expense_id', $id);
		$this->db->delete($this->table);
	}
	public function getImage($id)//delete user //delete_pic_id
	{
		$this->db->select('expense_attach');
		$this->db->from('expenses');
		$this->db->where('expense_id',$id);
		$query = $this->db->get();
		return $query->row()->expense_attach;
	}
	public function getById($id)//fetch oly details of a particular user,for updating
	{
		$this->db->from($this->table);
		$this->db->where('expense_id',$id);
		$query = $this->db->get();
		return $query->row();
	}
	public function updateExpense($where,$data)//updating user
	{
		$this->db->update($this->table,$data,$where);
		return $this->db->affected_rows();
	}
}
