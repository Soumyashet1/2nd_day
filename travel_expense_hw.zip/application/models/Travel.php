<?php
class Travel extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getAllTravels()//(admin_view)shows all travels list wit expenditure
	{
		$this->db->select('t.travel_id,t.travel_name,t.travel_desc,
		   					GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,
									ts.travel_status_name as status');
		$this->db->from('travels t');
		$this->db->join('travel_statuses ts', 't.travel_status_id=ts.travel_status_id','left');
		$this->db->join('travels_assigned ta', 't.travel_id=ta.travel_id','left');
		$this->db->join('employees emp', 'ta.employee_id=emp.employee_id','left');
		$this->db->group_by('t.travel_id');
		$query = $this->db->get();
		return $query->result();
	}
	public function addTravel($data)//adding new travel
	{
		$this->db->insert('travels',$data);
		return $this->db->insert_id();
	}
	public function deleteById($id)//delete travel
	{
		$this->db->where('travel_id', $id);
		$this->db->delete('travels');
	}
	public function assignEmployeesForTravel($data)//insertin employee ids in 'travels_assigned' table
	{
		foreach ($data['employee_ids'] as $val)
		{
			$this->db->set('employee_id',$val);
			$this->db->set('travel_id',$data['inserted_travel_id']);
			$this->db->insert('travels_assigned');
		}
	}
	public function getById($id)//fetch oly details of a particular travel,for updating
	{
		$this->db->from('travels');
		$this->db->where('travel_id',$id);
		$query = $this->db->get();
		return $query->row();
	}
	public function updateTravelDetails($where,$data)//updating travel_details
	{
		$this->db->update('travels',$data,$where);
		return $this->db->affected_rows();
	}
}
