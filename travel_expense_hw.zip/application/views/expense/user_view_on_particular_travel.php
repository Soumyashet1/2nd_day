<!-- user view on particular travel -->
<div class="container">
<h1>Expenses(user view on particular travel)</h1>
    <button class="btn btn-success" onclick="add_expense()">
    <i class="glyphicon glyphicon-plus"></i>
    Add Expense</button>
    <br>
 <br>
   <ul class="nav nav-pills nav-justified">
    <li class="active"><a data-toggle="pill" href="#all">All</a></li>
    <li><a data-toggle="pill" href="#pending">Pending</a></li>
    <li><a data-toggle="pill" href="#accepted">Accepted</a></li>
    <li><a data-toggle="pill" href="#rejected">Rejected</a></li>
  </ul>
  <div class="tab-content">
    <div id="all" class="tab-pane fade in active">
    <?php if(count($all)>0) { ?>
                      <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Expense_id</th>
                          <th>Expense_Date</th>
                          <th>Expense_Time</th>
                          <th>Expense_category</th>
                          <th>Description</th>
                          <th>Price</th>
                          <th>Attachment</th>
                          <th>Status</th>
                          <th style="width:125px;">Action</th>
                         </tr>
                      </thead>
                      <tbody>
                        <?php foreach($all as $usr){?>
                  	  <tr>
                  		<td><?php echo $usr->expense_id;?></td>
                  		<td><?php echo $usr->expense_date;?></td>
                  		<td><?php echo $usr->expense_time;?></td>
                  		<td><?php echo $usr->expense_category_name;?></td>
                          <td><?php echo $usr->expense_desc;?></td>
                          <td><?php echo $usr->expense_price;?></td>
                          <td  style="width:10%;"><img src="<?php echo base_url('images/'.$usr->expense_attach)?>" width="50%" ></td>
                          <td><?php echo $usr->expense_status_name;?></td>
                          <td>
                  		 <button class="btn btn-warning" onclick="update_expense(<?php echo $usr->expense_id;?>)" ><i class="glyphicon glyphicon-pencil"></i></button>
                  		 <button class="btn btn-danger" onclick="delete_expense(<?php echo $usr->expense_id;?>)"><i class="glyphicon glyphicon-remove"></i></button>
                  		</td>
                        </tr>
                      <?php }?>
                      </tbody>
                      </table>
                      <?php }
                      else {
                          echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
                      }?>
    </div>

    <div id="pending" class="tab-pane fade">
    <?php if(count($pending)>0) { ?>
                      <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Expense_id</th>
                          <th>Expense_Date</th>
                          <th>Expense_Time</th>
                          <th>Expense_category</th>
                          <th>Description</th>
                          <th>Price</th>
                          <th>Attachment</th>
                          <th>Status</th>
                          <th style="width:125px;">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($pending as $usr){?>
                  	  <tr>
                  		<td><?php echo $usr->expense_id;?></td>
                  		<td><?php echo $usr->expense_date;?></td>
                  		<td><?php echo $usr->expense_time;?></td>
                  		<td><?php echo $usr->expense_category_name;?></td>
                          <td><?php echo $usr->expense_desc;?></td>
                          <td><?php echo $usr->expense_price;?></td>
                          <td  style="width:10%;"><img src="<?php echo base_url('images/'.$usr->expense_attach)?>" width="50%" ></td>
                          <td><?php echo $usr->expense_status_name;?></td>
                           <td>
                  		 <button class="btn btn-warning" ><i class="glyphicon glyphicon-pencil"></i></button>
                  		 <button class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
                  		</td>
                        </tr>
                        <?php }?>
                      </tbody>
                      </table>
    <?php }
    else {
        echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
  </div>
    <div id="accepted" class="tab-pane fade">
    <?php if(count($accepted)>0) { ?>
                        <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th>Expense_id</th>
                            <th>Expense_Date</th>
                            <th>Expense_Time</th>
                            <th>Expense_category</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Attachment</th>
                            <th>Status</th>
                            <th style="width:125px;">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach($accepted as $usr){?>
                    	  <tr>
                    		<td><?php echo $usr->expense_id;?></td>
                    		<td><?php echo $usr->expense_date;?></td>
                    		<td><?php echo $usr->expense_time;?></td>
                    		<td><?php echo $usr->expense_category_name;?></td>
                            <td><?php echo $usr->expense_desc;?></td>
                            <td><?php echo $usr->expense_price;?></td>
                            <td  style="width:10%;"><img src="<?php echo base_url('images/'.$usr->expense_attach)?>" width="50%" ></td>
                            <td><?php echo $usr->expense_status_name;?></td>
                             <td>
                    		 <button class="btn btn-warning" ><i class="glyphicon glyphicon-pencil"></i></button>
                    		 <button class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
                    		</td>
                          </tr>
                          <?php }?>
                        </tbody>
                        </table>
    <?php }
    else {
      echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
  </div>
    <div id="rejected" class="tab-pane fade">
    <?php if(count($rejected)>0) { ?>
                      <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Expense_id</th>
                          <th>Expense_Date</th>
                          <th>Expense_Time</th>
                          <th>Expense_category</th>
                          <th>Description</th>
                          <th>Price</th>
                          <th>Attachment</th>
                          <th>Status</th>
                          <th style="width:125px;">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($rejected as $usr){?>
                  	  <tr>
                  		<td><?php echo $usr->expense_id;?></td>
                  		<td><?php echo $usr->expense_date;?></td>
                  		<td><?php echo $usr->expense_time;?></td>
                  		<td><?php echo $usr->expense_category_name;?></td>
                          <td><?php echo $usr->expense_desc;?></td>
                          <td><?php echo $usr->expense_price;?></td>
                          <td  style="width:10%;"><img src="<?php echo base_url('images/'.$usr->expense_attach)?>" width="50%" ></td>
                          <td><?php echo $usr->expense_status_name;?></td>
                           <td>
                  		 <button class="btn btn-warning" ><i class="glyphicon glyphicon-pencil"></i></button>
                  		 <button class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
                  		</td>
                          </tr>
                        <?php }?>
                      </tbody>
                      </table>
    <?php }
    else {
      echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
    </div>
  </div>


    <!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h3 class="modal-title">Expense Form</h3>
      </div>
    <form id="form"  method="post" enctype="multipart/form-data" class ="form-horizontal" onsubmit="save(<?php echo $tid;?>)">
      <div class="modal-body form">
        <div class="form-body">
                <input type="hidden" value="" name="expense_id"/>
                    <div class="form-group">
                            <label class="control-label col-md-3">Date</label>
                            <div class="col-md-9">
                                  <input name="expense_date" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text">
                                   <span class="help-block"></span>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3">Time</label>
                            <div class="col-md-9">
                                  <input name="expense_time" placeholder="Expense_time" class="form-control" type="time" >
                                   <span class="help-block"></span>
                            </div>
                    </div>
                    <div class="form-group">
                            <label class="control-label col-md-3">Category</label>
                            <div class="col-md-9">
                                 <select name="expense_category_id" class="form-control">
                      				    <?php foreach($categories as $usr){?>
                       						<option value="<?php echo $usr->expense_category_id;?>"><?php echo $usr->expense_category_name;?></option>
                      					 <?php }?>
                      					 </select>
                  			   </div>
                    </div>
                    <div class="form-group">
                          <label class="control-label col-md-3">Description</label>
                          <div class="col-md-9">
                                <textarea name="expense_description" placeholder="Expense Description" class="form-control"></textarea>
                                 <span class="help-block"></span>
                          </div>
                    </div>
                    <div class="form-group">
                  				<label class="control-label col-md-3">Price</label>
                  			  <div class="col-md-9">
                  					<input name="expense_price" placeholder="Expense Price" class="form-control" type="text">
                            <span class="help-block"></span>
                  				</div>
                  	</div>
                    <div class="form-group">
                  				<label class="control-label col-md-3">Expense_attachment</label>
                  				<div class="col-md-9">
                  					<input name="userfile" type="file"  size="200" class="form-control">
                  			  </div>
                  	</div>
          </div>
          <div class="modal-footer">
            <button type="submit"  class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>
<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
<script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
<script src="<?php echo base_url('assests/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,
    });
  } );
  var save_method;
  var table;
  function add_expense()
  {
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.form-group').removeClass('has-error'); // clear error class
   $('.help-block').empty(); // clear error string
    $('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
  }
  function save(tid)
  {
    var form = $('#form')[0];
    var data = new FormData(form);
    console.log(data);
    var url;
    if(save_method == 'add')
    {
        url = "<?php echo base_url('expenses/expense_add')?>/"+tid;
    }
    else
    {
        url = "<?php echo base_url('expenses/update_expense_details')?>";
    }
        $.ajax({
          url : url,
          type: "POST",
          data:  new FormData(form),
          enctype: 'multipart/form-data',
          processData: false,  // Important!
          contentType: false,
          cache: false,
          success: function(data)
          {
                  $('#modal_form').modal('hide');
                  reload_table();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error in adding / update data');
          }
      });
  }
  function delete_expense(id)
  {
    if(confirm('Are you sure delete this data?'))
    {
          $.ajax({
          url : "<?php echo base_url('expenses/delete_expense')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
             location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error deleting data');
          }
      });
    }
  }
  function delete_pic()
  {
    $filename = "<?php echo base_url('images/noimage.jpg')?>";

     if (!empty($filename))
     {
       alert("<?php echo base_url('images/noimage.jpg')?>");
         unlink($filename);
     }
  }
  function update_expense(id)
  {
    save_method = 'update';
    $('#form')[0].reset();
    $.ajax({
      url : "<?php echo base_url('/expenses/get_expense_details_by_id')?>/" + id,
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {
          $('[name="expense_id"]').val(data.expense_id);
          $('[name="expense_date"]').datepicker('update',data.expense_date);
          $('[name="expense_time"]').val(data.expense_time);
          $('[name="expense_category_id"]').val(data.expense_category_id);
          $('[name="expense_description"]').val(data.expense_desc);
          $('[name="expense_price"]').val(data.expense_price);
          //$('[name="userfile"]').val(data.expense_attach);
          $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
          $('.modal-title').text('Edit user Details'); // Set title to Bootstrap modal title
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
          alert('Error get data from ajax');
      }
  });
  }
</script>
