<!-- admin view on particular travel -->
<div class="container">
<h1>Expenses(admin view on particular travel)</h1>
   <ul class="nav nav-pills nav-justified">
    <li class="active"><a data-toggle="pill" href="#all">All</a></li>
    <li><a data-toggle="pill" href="#pending">Pending</a></li>
    <li><a data-toggle="pill" href="#accepted">Accepted</a></li>
    <li><a data-toggle="pill" href="#rejected">Rejected</a></li>
  </ul>
  <div class="tab-content">
    <div id="all" class="tab-pane fade in active">
      <?php if(count($all)>0) { ?>
                      <table id="table_id" class="table table-responsive table-striped table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Expense_id</th>
                                      <th>Employee_Name</th>
                                      <th>Expense_Date</th>
                                      <th>Expense_Time</th>
                                      <th>Expense_category</th>
                                      <th>Description</th>
                                      <th>Price</th>
                                      <th>Status</th>
                                      <th style="width:125px;">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php foreach($all as $usr){?>
                              	  <tr>
                              		<td><?php echo $usr->expense_id;?></td>
                              		<td><?php echo $usr->first_name;?></td>
                              		<td><?php echo $usr->expense_date;?></td>
                              		<td><?php echo $usr->expense_time;?></td>
                              		<td><?php echo $usr->expense_category_name;?></td>
                                      <td><?php echo $usr->expense_desc;?></td>
                                      <td><?php echo $usr->expense_price;?></td>
                                      <td><?php echo $usr->expense_status_name;?></td>
                                      <td>
                                        <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Accepted'){ ?>
                                          disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                          <i class="glyphicon glyphicon-ok"></i>
                                        </button>
                                        <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Rejected'){ ?>
                                          disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                          <i class="glyphicon glyphicon-remove"></i>
                                        </button>
                                      </td>
                                    </tr>
                                    <?php }?>
                                  </tbody>
                                  </table>
    <?php }
    else {
        echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
    </div>

    <div id="pending" class="tab-pane fade">
    <?php if(count($pending)>0) { ?>
                                              <table id="table_id" class="table table-responsive table-striped table-bordered">
                                                  <thead>
                                                    <tr>
                                                      <th>Expense_id</th>
                                                      <th>Employee_Name</th>
                                                      <th>Expense_Date</th>
                                                      <th>Expense_Time</th>
                                                      <th>Expense_category</th>
                                                      <th>Description</th>
                                                      <th>Price</th>
                                                      <th>Status</th>
                                                      <th style="width:125px;">Action</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                    <?php foreach($pending as $usr){?>
                                              	  <tr>
                                              		<td><?php echo $usr->expense_id;?></td>
                                              		<td><?php echo $usr->first_name;?></td>
                                              		<td><?php echo $usr->expense_date;?></td>
                                              		<td><?php echo $usr->expense_time;?></td>
                                              		<td><?php echo $usr->expense_category_name;?></td>
                                                      <td><?php echo $usr->expense_desc;?></td>
                                                      <td><?php echo $usr->expense_price;?></td>
                                                      <td><?php echo $usr->expense_status_name;?></td>
                                                      <td>
                                                        <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Accepted'){ ?>
                                                          disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                                          <i class="glyphicon glyphicon-ok"></i>
                                                        </button>
                                                        <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Rejected'){ ?>
                                                          disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                                          <i class="glyphicon glyphicon-remove"></i>
                                                        </button>
                                                      </td>
                                                    </tr>
                                                    <?php }?>
                                                  </tbody>
                                                  </table>
    <?php }
    else {
        echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
  </div>
    <div id="accepted" class="tab-pane fade">
    <?php if(count($accepted)>0) { ?>
                                <table id="table_id" class="table table-responsive table-striped table-bordered">
                                        <thead>
                                          <tr>
                                            <th>Expense_id</th>
                                            <th>Employee_Name</th>
                                            <th>Expense_Date</th>
                                            <th>Expense_Time</th>
                                            <th>Expense_category</th>
                                            <th>Description</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th style="width:125px;">Action</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach($accepted as $usr){?>
                                    	  <tr>
                                    		<td><?php echo $usr->expense_id;?></td>
                                    		<td><?php echo $usr->first_name;?></td>
                                    		<td><?php echo $usr->expense_date;?></td>
                                    		<td><?php echo $usr->expense_time;?></td>
                                    		<td><?php echo $usr->expense_category_name;?></td>
                                        <td><?php echo $usr->expense_desc;?></td>
                                        <td><?php echo $usr->expense_price;?></td>
                                        <td><?php echo $usr->expense_status_name;?></td>
                                        <td>
                                          <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Accepted'){ ?>
                                            disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                            <i class="glyphicon glyphicon-ok"></i>
                                          </button>
                                          <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Rejected'){ ?>
                                            disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                            <i class="glyphicon glyphicon-remove"></i>
                                          </button>
                                        </td>
                                          </tr>
                                          <?php }?>
                                        </tbody>
                                        </table>
    <?php }
    else {
    echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
  </div>
  <div id="rejected" class="tab-pane fade">
  <?php if(count($rejected)>0) { ?>
                        <table id="table_id" class="table table-responsive table-striped table-bordered">
                                        <thead>
                                          <tr>
                                            <th>Expense_id</th>
                                            <th>Employee_Name</th>
                                            <th>Expense_Date</th>
                                            <th>Expense_Time</th>
                                            <th>Expense_category</th>
                                            <th>Description</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th style="width:125px;">Action</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach($rejected as $usr){?>
                                    	  <tr>
                                    		<td><?php echo $usr->expense_id;?></td>
                                    		<td><?php echo $usr->first_name;?></td>
                                    		<td><?php echo $usr->expense_date;?></td>
                                    		<td><?php echo $usr->expense_time;?></td>
                                    		<td><?php echo $usr->expense_category_name;?></td>
                                            <td><?php echo $usr->expense_desc;?></td>
                                            <td><?php echo $usr->expense_price;?></td>
                                            <td><?php echo $usr->expense_status_name;?></td>
                                            <td>
                                              <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Accepted'){ ?>
                                                disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                                <i class="glyphicon glyphicon-ok"></i>
                                              </button>
                                              <button class="btn btn-primary" <?php if($usr->expense_status_name == 'Rejected'){ ?>
                                                disabled <?php } ?> onclick="edit_status_to_accepted(<?php echo $usr->expense_id;?>)">
                                                <i class="glyphicon glyphicon-remove"></i>
                                              </button>
                                            </td>
                                          </tr>
                                          <?php }?>
                                        </tbody>
                                        </table>
    <?php }
    else {
        echo "<h4 style='text-align:center; color: #286090;border: 2px solid #5cb85c';>No records</h4>";
    }?>
  </div>
  </div>
</div>
<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>

<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );
  function edit_status_to_accepted(id)
  {
          $.ajax({
          url : "<?php echo base_url('index.php/expenses/edit_exp_accepted')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
             location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error editing data');
          }
      });
  }
  function edit_status_to_rejected(id)
  {
          $.ajax({
          url : "<?php echo base_url('index.php/expenses/edit_exp_rejected')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
             location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error editing data');
          }
      });
  }
</script>
