<div class="container">
  <h1>Travels</h1>
  <button class="btn btn-success" onclick="add_travel()">
    <i class="glyphicon glyphicon-plus"></i>
    Add Travel
  </button>
  <br>
  <br>
  <table id="table_id" class="table table-responsive table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
      <th>Travel_id</th>
      <th>Travel_Name</th>
      <th>Employess_Assigned</th>
      <th>Description</th>
      <th>Start_Date</th>
      <th>End_Date</th>
      <th>Travel_status</th>
      <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($travel as $usr){?>
        <tr>
          <td><?php echo $usr->travel_id;?></td>
          <td><?php echo $usr->travel_name;?></td>
          <td><?php echo $usr->Employees;?></td>
          <td><?php echo $usr->travel_desc;?></td>
          <td><?php echo $usr->travel_start_date;?></td>
          <td><?php echo $usr->travel_end_date;?></td>
          <td><?php echo $usr->status;?></td>
          <td>
          <button class="btn btn-warning" onclick="update_travel(<?php echo $usr->travel_id;?>)" ><i class="glyphicon glyphicon-pencil"></i></button>
          <button class="btn btn-danger" onclick="delete_travel(<?php echo $usr->travel_id;?>)"><i class="glyphicon glyphicon-remove"></i></button>
          </td>
        </tr>
      <?php }?>
    </tbody>
  </table>
  <div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h3 class="modal-title">Travel Form</h3>
        </div>
        <div class="modal-body form">
          <form action="#" id="form" class="form-horizontal">
            <div class="form-body">
              <input type="hidden" value="" name="tid"/>
              <div class="form-group">
                <label class="control-label col-md-3">Travel Name</label>
                <div class="col-md-9">
                  <input name="travel_name" placeholder="Travel Name" class="form-control" type="text" >
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3">Travel description</label>
                <div class="col-md-9">
                  <textarea name="travel_description" placeholder="Travel description" class="form-control" ></textarea>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3">Start Date</label>
                <div class="col-md-9">
                  <input name="travel_start_date"  class="form-control" type="date">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3">End Date</label>
                <div class="col-md-9">
                  <input name="travel_end_date"  class="form-control" type="date">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3">Employees Assigned</label>
                <div class="col-md-9">
                  <select name="employee_ids[]"  multiple="multiple" class="form-control">
                    <?php foreach($employees as $usr){?>
                    <option value="<?php echo $usr->employee_id;?>"><?php echo $usr->first_name;?> <?php echo $usr->last_name;?></option>
                    <?php }?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-9">
                  <input name="travel_status_id" class="form-control" type="hidden">
                </div>
              </div>
            </div>
          </form>
        </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
</div>
<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
<script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
<script type="text/javascript">
  $(document).ready( function () {
        $('#table_id').DataTable();
    } );
      var save_method; //for save method string
      var table;
      function add_travel()
      {
        save_method = 'add';
        $('#form')[0].reset(); // reset form on modals
        $('#modal_form').modal('show'); // show bootstrap modal
      }
      function save()
      {
        var url;
        if(save_method == 'add')
        {
            url = "<?php echo base_url('index.php/travels/add_travel');?>";
        }
        else
        {
            url = "<?php echo base_url('index.php/travels/update_travel_details')?>";
        }
              $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success:function(data)
              {
                $('#modal_form').modal('hide');
                location.reload();// for reload a page
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error in adding / update data');
              }
          });
      }
      function delete_travel(id)
      {
        if(confirm('Are you sure delete this data?'))
        {
              $.ajax({
              url : "<?php echo base_url('travels/delete_travel')?>/"+id,
              type: "POST",
              dataType: "JSON",
              success: function(data)
              {
                 location.reload();
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error deleting data');
              }
          });
        }
      }
      function update_travel(id)
      {
        save_method = 'update';
        $('#form')[0].reset();
        $.ajax({
          url : "<?php echo base_url('/travels/get_travel_details_by_id')?>/" + id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
              $('[name="tid"]').val(data.travel_id);
              $('[name="travel_name"]').val(data.travel_name);
              $('[name="travel_description"]').val(data.travel_desc);
              $('[name="travel_start_date"]').val(data.travel_start_date);
              $('[name="travel_end_date"]').val(data.travel_end_date);
              $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
              $('.modal-title').text('Edit Travel Details'); // Set title to Bootstrap modal title
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error get data from ajax');
          }
      });
  }
</script>
