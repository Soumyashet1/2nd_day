<html>
<head>
<style type="text/css">
.wrap {
padding: 2.5em;
width: 100%;
margin:6em auto auto auto;
/*background: rgba(0, 0, 0, 0.55);*/
border:2px solid #ca4141;
}
.project_title{
  color: #de0000;
text-align: center;
margin-top: 5%;
}
.bg {
  background: url(<?php echo base_url('assests/images/bg.jpg')?>) no-repeat;
	background-size: cover;
	background-attachment: fixed;
}
.error {
      color: red;
}
</style>
</head>
<body class="bg">
  <h1 class="project_title">TRAVEL EXPENSE TRACKER</h1>
<div class="row">
     <div class="col-md-4 col-md-offset-1" >
       <div class="wrap">
         <h3 class="project_title">Login</h3>
         <form action="" method="post">
           <?php validation_errors();?>
           Email-id:<input type="text" name="email" class="form-control">
           <span class="error"><?php echo form_error('email');?></span>
           Password:<input type="password" name="password" class="form-control">
           <span class="error"><?php echo form_error('password'); ?></span>
           <br>
           <br>
           <input type="submit" value="login" class="form-control btn-danger">
         </form>
       </div>
     </div>
   </div>
  </body>
</html>
