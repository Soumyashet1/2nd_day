<div class="container">
<h1>Users</h1>
<button class="btn btn-success" onclick="add_user()">
    <i class="glyphicon glyphicon-plus"></i>
    Add Users</button>
    <br>
    <br>
<table id="table_id" class="table table-responsive table-striped table-bordered">
    <thead>
      <tr>
       <th>#id</th>
        <th>Employee_id</th>
        <th>First_Name</th>
        <th>Last_Name</th>
        <th>Email-id</th>
        <th>Employee_role</th>
        <th>department</th>
        <th>Actions</th>
       </tr>
    </thead>
    <tbody>
      <?php foreach($user as $usr){?>
	  <tr>
	  <td><?php echo $usr->id;?></td>
		<td><?php echo $usr->employee_id;?></td>
		<td><?php echo $usr->first_name;?></td>
		<td><?php echo $usr->last_name;?></td>
		<td><?php echo $usr->email_id;?></td>
		<td><?php echo $usr->role_name;?></td>
    <td><?php echo $usr->department_name;?></td>
    <td>
    <button class="btn btn-warning" onclick="update_user(<?php echo $usr->id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
    <button class="btn btn-danger" onclick="delete_user(<?php echo $usr->id;?>)"><i class="glyphicon glyphicon-remove"></i></button>
    </td>
       </tr>
      <?php }?>
    </tbody>
  </table>
<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Users Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <div class="form-body">
          <div class="form-group">
              <div class="col-md-9">
                <input name="id"  value=""  class="form-control" type="hidden" >
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Employee_id</label>
              <div class="col-md-9">
                <input name="employee_id" id="employee_id" placeholder="Employee_id" class="form-control" type="text" >
                <?php echo form_error('employee_id');?>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">First_Name</label>
              <div class="col-md-9">
                <input name="first_name" placeholder="First Name" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
				<label class="control-label col-md-3">Last_Name</label>
				<div class="col-md-9">
				   <input name="last_name" placeholder="Last Name" class="form-control" type="text">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3">Employee_role</label>
				<div class="col-md-9">
					<select name="employee_role_id"  class="form-control">
					<?php foreach($roles as $usr){?>
 						<option value="<?php echo $usr->role_id;?>"><?php echo $usr->role_name;?></option>
					 <?php }?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3">Department</label>
				<div class="col-md-9">
					<select name="dept_id"  class="form-control">
					<?php foreach($departments as $usr){?>
 						<option value="<?php echo $usr->department_id;?>"><?php echo $usr->department_name;?></option>
					 <?php }?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3">Email-id</label>
				<div class="col-md-9">
					<input name="email_id" placeholder="Email-id" class="form-control" type="text">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3">Password</label>
				<div class="col-md-9">
					<input name="password" placeholder="Password" class="form-control" type="text">
				</div>
			</div>
		</div>
        </form>
      </div>
      <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
</div>
<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
<script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
<script type="text/javascript">
$(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;
    function add_user()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    }
    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo base_url('index.php/logins/add_user');?>";
      }
      else
      {
          url = "<?php echo base_url('index.php/logins/update_user_details')?>";
      }
            $.ajax({
            url : url,
            type: "POST",
              data: $('#form').serialize(),
            dataType: "JSON",
            success:function(data)
            {
              $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error in adding / update data');
            }
        });
    }
    function delete_user(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
            $.ajax({
            url : "<?php echo base_url('logins/delete_user')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
      }
    }
    function update_user(id)
    {
      save_method = 'update';
      $('#form')[0].reset();
      $.ajax({
        url : "<?php echo base_url('/logins/get_user_details_by_id')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="id"]').val(data.id);
            $('[name="employee_id"]').val(data.employee_id);
            $('[name="first_name"]').val(data.first_name);
            $('[name="last_name"]').val(data.last_name);
            $('[name="employee_role_id"]').val(data.employee_role_id);
            $('[name="dept_id"]').val(data.department_id);
            $('[name="email_id"]').val(data.email_id);
            $('[name="password"]').val(data.password);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit user Details'); // Set title to Bootstrap modal title
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }
  </script>
