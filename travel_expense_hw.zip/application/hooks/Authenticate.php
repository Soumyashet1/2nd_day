<?php
class Authenticate extends CI_Controller
{
    var $CI;
    var $lang;
    function Authenticate()
    {
      $this->CI =& get_instance();
    }
    function checkUserLogin()
    {
      if(!$this->checkForAllowedUrlsWithoutLogin())
        {
          if(!$this->CI->session->userdata('logged_in'))
          {
                redirect('logins/index');
          }
        }
    }
    function checkForAllowedUrlsWithoutLogin()
    {
      $segment1=$this->CI->uri->segment(1);
      $segment2=$this->CI->uri->segment(2);
      $arrAllowedUrls=array();
      $arrAllowedUrls[]=array('logins','index');
      $isAllowed=false;
      foreach($arrAllowedUrls as $row)
      {
          if($row[1] == '')
          {
              if($segment1==$row[0])
                  $isAllowed=true;
          }
          else
          {
              if($segment1==$row[0] && $segment2==$row[1])
                  $isAllowed=true;
          }
      }
      return $isAllowed;
   }
}
?>
